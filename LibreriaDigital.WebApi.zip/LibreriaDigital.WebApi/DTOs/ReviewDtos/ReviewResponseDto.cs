﻿public class ReviewResponseDto
{
    public int Id { get; set; }
    public int Calificacion { get; set; }
    public string Comentario { get; set; }
    public int BookId { get; set; }
    public int UserId { get; set; }
}
