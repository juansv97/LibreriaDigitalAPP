﻿public class UserResponseDto
{
    public int Id { get; set; }
    public string NombreCompleto { get; set; }
    public string Correo { get; set; }
}
